<html>
	<head>
		<title>
		Your email has been sent..
		</title>
	</head>
	
	<body>
		<h2>Your email has been sent</h2>
		We will get back to you shortly. Click the back arrow to return to the previous page.
		<br />
			<?php
			ini_set("include_path", '/home/f1642879/php:' . ini_get("include_path")  );
			$mess_safe=strip_tags($_POST['message']);//strip html tags for security
			
			mail("admin@housedepot.co.za", "Housedepot email", $mess_safe);
			?>
	</body>
</html>
